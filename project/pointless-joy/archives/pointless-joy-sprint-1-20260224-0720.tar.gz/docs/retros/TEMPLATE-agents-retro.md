# Sprint {{SPRINT}} — Agents Retrospective

## 1) Sprint Goal vs Result
- Goal:
- Result:
- Completion (%):

## 2) What each agent did
- pointless-팀장:
- pointless-스토리:
- pointless-경험설계:
- pointless-빌더:
- pointless-디자인리뷰어:
- pointless-코드리뷰어:

## 3) Wins
- 

## 4) Misses / Risks
- 

## 5) PRODUCT_SPEC alignment
- Spec sections covered:
- Out-of-scope work:
- Open gaps:

## 6) Next Sprint actions (Top 5)
1.
2.
3.
4.
5.
